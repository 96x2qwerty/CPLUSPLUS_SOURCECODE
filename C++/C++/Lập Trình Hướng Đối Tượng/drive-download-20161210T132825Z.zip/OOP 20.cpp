#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;
class dathuc
{
      int n;
      float *p;
      public:
             dathuc();
             dathuc(int );
             ~dathuc();
             dathuc( const dathuc &);
             void nhap();
             void xuat();
             float giatri( float);
             dathuc cong2dt(dathuc );
             bool sosanh( dathuc );
};
dathuc::dathuc()
{
                n=0;
                p=NULL; 
}
dathuc::dathuc( int x)
{
                n=x;
                p= new float [x+1];
                for(int i=0;i<=n; i++)
                p[i]=1;
}
dathuc::~dathuc()
{
                 n=0;
                 delete[] p;
}
dathuc::dathuc( const dathuc &a)
{
        n=a.n;
        p=new float [n+1];
        for( int i=0;i<=n; i++)
        p[i]= a.p[i];
}
void dathuc::nhap()
{
     cout<<"\nNhap bac cua da thuc: ";
     cin>>n;
     p=new float [n+1];
     cout<<"Nhap cac he so tu bac cao den bac thap: ";
     for(int i=n;i>=0; i--)
     cin>>p[i];
}
void dathuc::xuat()
{
     cout<<"\nDa thuc: ";
     for(int i=n; i>0; i--)
     cout<<p[i]<<"*x^"<<i<<" + ";
     if( n>0 )cout<<p[0];
}
float dathuc::giatri(float x)
{
      float kq=0;
      for(int i=0; i<=n; i++)
      kq+= p[i]*pow(x,i);
      return kq;
}
dathuc dathuc::cong2dt(dathuc b)
{
       dathuc c;
       c.n=( b.n >n )? b.n:n;
       c.p= new float [c.n+1];
       for(int i=0; i<=c.n; i++)
       {
               c.p[i]=0;
               if( b.n>=i ) c.p[i]+= b.p[i];
               if( n>=i ) c.p[i]+= p[i];
       }
       return c;
}
bool dathuc::sosanh( dathuc b)
{
     if( n!= b.n) return false;
     for(int i=0; i<=n; i++)
     if (p[i] != b.p[i]) return false;
     return true;
}     
main()
{
      dathuc a,b;
      a.nhap();
      b.nhap();
      a.xuat();
      b.xuat();
      if( a.sosanh(b)) cout<<"\nDa thuc a giong da thuc b\n";
      dathuc c(a.cong2dt(b));
      c.xuat();
      cout<<endl<<c.giatri(2.1);
      
      getch();
      return 0;
}
      
