#include<conio.h>
#include<iostream>
using namespace std;
template <class T, class U> class HH
{
      string ten;
      T *ma;
      int soluong;
      U dongia;
      public:
             HH()
             {
                 ten ="";
                 ma = NULL;
                 soluong =0;
                 dongia =U(0);
             }
             void nhap();
             void xuat();
             U tongtien() { return soluong * dongia; }
             float lai() { return 0.1 * tongtien(); }
};
template <class T, class U> void HH<T,U>::nhap()
{
     cout<<"\nNhap ten: ";
     getline ( cin, ten);
     cout<<"Nhap ma: ";
     ma= new T;
     cin>>*ma;
     cout<<"Nhap so luong: ";
     cin>>soluong;
     cout<<"Nhap don gia: ";
     cin>>dongia;
     cin.ignore(1);
}
template <class T, class U> void HH<T,U> ::xuat()
{
     cout<<"\n\nTen: "<<ten<<"\nMa: "<<*ma
     <<"\nSo luong: "<<soluong<<"\nDon gia: "<<dongia
     <<"\nLai: "<<lai();
}
main()
{
      HH<string,int> a;
      HH<int, float> b;
      a.nhap();
      b.nhap();
      a.xuat();
      b.xuat();
      getch();
      return 0;
}
