#include<iostream>
#include<conio.h>
using namespace std;
class node
{
      float data;
      node *link;
      public:
             node()
             {
                   data =0;
                   link = NULL;
             }
             friend class taphop;
};
class taphop 
{
      node *head, *last;
      public:
             taphop()
             {
                     head = last= NULL;
             }
             bool ktra( float );
             void operator + ( float);
             bool operator - ( float &);
             friend ostream &operator <<( ostream &, taphop );
             friend istream &operator >>( istream &, taphop &);
             float get(int );
             taphop operator + ( taphop );
             void operator = (taphop );
             float operator [] ( int );
};
bool taphop::ktra( float x )
{
     node *p = head;
     while ( p!= NULL)
     {
           if ( p->data == x ) return true;
           else p=p->link;
     }
     return false;
}
void taphop::operator+ ( float x) // them 1 phan tu vao cuoi danh sach
{
     node *p;
     p=new node;
     p->data = x;
     p->link = NULL;
     if( head == NULL ) 
     {
         head = last= p;
     }
     else
     {
          last -> link = p;
          last= p;
     }
}
bool taphop::operator -(float &x) // lay 1 phan tu o dau danh sach
{
     if( head == NULL ) return false;
     else 
     {
          x=head -> data;
          node *p = head;
          if (head == last) head = last = NULL;
          else  head = p->link;
     }
     return true;
}
ostream &operator <<( ostream &os,taphop t)
{
        float x;
        while ( t.head!= NULL)
        {
              t-x;
              os<<x<<endl;
        }
}
istream &operator >>( istream &is, taphop &t)
{
        float x;
        cout<<"Nhap gia tri: ( -1 la dung ): ";
        is>>x;
        while( x!= -1)
        {
               t+x;
               cin>>x;
        }
        return is;
}
float taphop::get(int i)
{
      for( node *p = head; p!= NULL; p=p->link )
      {
           if( i==0 ) return p->data;
           else i--;
      }
      return -10000;
}
void taphop::operator = ( taphop b)
{
     node *p =head;
     while( p!= NULL) 
     {
            head = p->link;
            delete p;
            p=head;
     }
     for(p=b.head; p!= NULL; p=p->link)
     (*this)+ (p->data);
}
taphop taphop::operator + (taphop b)
{
       taphop c;
       float x;
       c=*this;
       for( node *p =b.head; p!= NULL; p=p->link)
       {
            if( !c.ktra(p->data) ) c+(p->data);
       }
       return c;
}
float taphop::operator [] ( int i )
{
      for( node *p = head; p!= NULL; p=p->link )
      {
           if( i==0 ) return p->data;
           else i--;
      }
      return -10000;
}
main()
{
      taphop a,b,c,d;
      cout<<"\nnhap tap hop a :";
      cin>>a;
      cout<<a;
      
      cout<<"\nnhap tap hop b :";
      cin>>b;
      cout<<b;
      cout<<"Tap hop c = a+b:\n";
      c=a+b;
      cout<<c;
      cout<<"\n c[2] = "<<c[2];
      getch();
      return 0;
}
